# ReactMVA
## Project Repository for the React Microsoft Virtual Academy Course

This is the repository containing the source code for all the demos and the PowerPoint presentations in the React Microsoft Virtual Academy course. This course was developed by Rami Sayar, Jeremy Foster && Lisa Wong; all are technical evangelists at Microsoft.
